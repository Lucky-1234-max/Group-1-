classdef NewtonRaphson
    properties
        f, df, tol, maxIter
    end
    methods
        function obj = NewtonRaphson(f, df, tol, maxIter)
            obj.f = f;
            obj.df = df;
            obj.tol = tol;
            obj.maxIter = maxIter;
        end
        
        function [root, converged] = solve(obj, x0)
            [root, converged] = obj.recursive_solve(x0, 1);
        end
        
        function [root, converged] = recursive_solve(obj, x, iter)
            if iter > obj.maxIter
                root = x;
                converged = false;
                return;
            end
            
            x_new = x - obj.f(x)/obj.df(x);
            fprintf('%d\t%.6f\n', iter, x_new);
            
            if abs(x_new - x) < obj.tol
                root = x_new;
                converged = true;
            else
                [root, converged] = obj.recursive_solve(x_new, iter + 1);
            end
        end
    end
end
