classdef DampedDrivenOscillator < ODESolver
    properties
        solver_name = 'Iterative ODE Solver'
    end
    
    methods
        function obj = DampedDrivenOscillator(system, dt, max_time, initial_conditions)
            if nargin >= 1
                obj.system = system;
            end
            if nargin >= 2
                obj.dt = dt;
            end
            if nargin >= 3
                obj.max_time = max_time;
            end
            if nargin >= 4
                obj.initial_conditions = initial_conditions;
            end
        end
        
        % POLYMORPHISM - Different implementation of abstract method
        function [time_points, solution] = solve(obj)
            num_steps = round(obj.max_time / obj.dt) + 1;
            time_points = linspace(0, obj.max_time, num_steps);
            solution = zeros(1, num_steps);
            
            x = obj.initial_conditions(1);
            xd = obj.initial_conditions(2);
            solution(1) = x;
            
            for i = 2:num_steps
                t = time_points(i-1);
                % Same interface, different implementation
                xdd = obj.system.compute_acceleration(t, x, xd);
                xd = xd + xdd * obj.dt;
                x = x + xd * obj.dt;
                solution(i) = x;
            end
            
            obj.plot_solution(time_points, solution);
        end
    end
end