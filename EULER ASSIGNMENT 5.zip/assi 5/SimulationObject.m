classdef SimulationObject < handle
    % PURE UNIVERSAL PARENT CLASS - Standalone
    properties
        name = 'Universal Simulation Object'
        creation_date
    end
    
    methods
        function obj = SimulationObject()
            obj.creation_date = datetime();
            fprintf('Universal parent created: %s\n', obj.name);
        end
        
        function displayInfo(obj)
            fprintf('=== %s ===\n', class(obj));
            fprintf('Name: %s\n', obj.name);
            fprintf('Created: %s\n', char(obj.creation_date));
        end
    end
    
    methods (Abstract)
        getType(obj)
    end
end