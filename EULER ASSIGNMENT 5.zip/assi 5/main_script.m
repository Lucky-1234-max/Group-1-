% Main script to run the ODE solver simulation
fprintf('ODE Solver Simulation Started...\n');

% Create different systems and solvers to demonstrate polymorphism
oscillator1 = DampedDrivenOscillator(3, 2, 2, 5);
oscillator2 = DampedDrivenOscillator(5, 1, 1, 3);

% Create different solvers - polymorphism in action
solver1 = RecursiveSolver(oscillator1, 0.01, 10, [0, 0]);
solver2 = IterativeSolver(oscillator2, 0.01, 5, [1, 0]);

% Solve using different methods - same interface
[t1, x1] = solver1.solve();
[t2, x2] = solver2.solve();

fprintf('Simulation completed successfully!\n');