classdef RecursiveSolver < ODESolver
    properties
        solver_name = 'Recursive ODE Solver'
    end
    
    methods
        function obj = RecursiveSolver(system, dt, max_time, initial_conditions)
            if nargin >= 1
                obj.system = system;
            end
            if nargin >= 2
                obj.dt = dt;
            end
            if nargin >= 3
                obj.max_time = max_time;
            end
            if nargin >= 4
                obj.initial_conditions = initial_conditions;
            end
        end
        
        % Implementing abstract method
        function [time_points, solution] = solve(obj)
            x0 = obj.initial_conditions(1);
            xd0 = obj.initial_conditions(2);
            
            solution = obj.solve_recursive(0, x0, xd0);
            time_points = 0:obj.dt:obj.max_time;
            
            obj.plot_solution(time_points, solution);
        end
        
        function result = solve_recursive(obj, t, x, xd)
            if t > obj.max_time
                result = [];
                return
            end
            
            % Polymorphic call - works with any DynamicSystem
            xdd = obj.system.compute_acceleration(t, x, xd);
            xd_new = xd + xdd * obj.dt;
            x_new = x + xd_new * obj.dt;
            
            next_vals = obj.solve_recursive(t + obj.dt, x_new, xd_new);
            result = [x_new, next_vals];
        end
    end
end