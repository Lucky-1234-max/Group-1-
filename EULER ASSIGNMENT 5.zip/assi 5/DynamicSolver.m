classdef DynamicSolver
    properties
        system_type = 'Generic'
    end
    
    methods
        function acceleration = compute_acceleration(~, ~, ~, ~)
            acceleration = 0;
        end
    end
end