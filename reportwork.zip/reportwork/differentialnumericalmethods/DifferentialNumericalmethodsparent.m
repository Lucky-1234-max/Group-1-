classdef (Abstract) DifferentialNumericalmethodsparent
    % PARENT CLASS for numerical computation problems
    
    properties (Access = protected)
        func            % Function to work with
        lower_limit     % Starting point
        upper_limit     % Ending point  
        num_steps       % Number of steps
    end

    methods  
        % Constructor - initializing the common parameters
        function obj = DifferentialNumericalmethodsparent(func, lower_limit, upper_limit, num_steps)
            obj.func = func;
            obj.lower_limit = lower_limit;
            obj.upper_limit = upper_limit;
            obj.num_steps = num_steps;
        end
    end

    methods (Abstract)
        result = solve(obj)        % Method to solve the problem
        display_result(obj, result) % Method to show results 
    end
end