%% Test 1: Lagrange Method
fprintf('1. Testing Lagrange Method...\n');
test_func = @(x) x.^3 + 2*x.^2 - x + 1;
lagrange_solver = sublagrange(test_func, -2, 2, 10);
result1 = lagrange_solver.solve();
lagrange_solver.display_result(result1);

%% Test 2: Fixed Point Method
fprintf('\n2. Testing Fixed Point Method...\n');
% Function for fixed point: cos(x) = x
fp_func = @(x) cos(x);
fp_solver = DifferentialFixedPoint(fp_func, 0, 1, 50, 100, 1e-8);
result2 = fp_solver.solve();
fp_solver.display_result(result2);

%% Test 3: Damped Driven Oscillator
fprintf('\n3. Testing Damped Driven Oscillator...\n');
% Simple damped oscillator: x'' = -0.1*x' - x + sin(t)
osc_func = @(t, x, xd) -0.1*xd - x + sin(t);
osc_solver = DampedDrivenOscillator(osc_func, 0, 10, 1000, 0.01, [1, 0]);
result3 = osc_solver.solve();
osc_solver.display_result(result3);

fprintf('\n=== All tests completed successfully! ===\n');