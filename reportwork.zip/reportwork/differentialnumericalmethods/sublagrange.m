classdef sublagrange < DifferentialNumericalmethodsparent
    % Lagrange interpolation for numerical differentiation
    
    methods
        function obj = sublagrange(func, lower_limit, upper_limit, num_steps)
            % Constructor calls parent class
            obj@DifferentialNumericalmethodsparent(func, lower_limit, upper_limit, num_steps);
        end

        function result = solve(obj)
            % Solve using Lagrange method
            x = linspace(obj.lower_limit, obj.upper_limit, obj.num_steps);
            y = obj.func(x);

            % Building the Lagrange polynomial
            xp = sym('xp');
            sm = 0;
            
            for i = 1:obj.num_steps
                pr = 1;
                for j = 1:obj.num_steps
                    if j ~= i
                        pr = pr * (xp - x(j)) / (x(i) - x(j));
                    end
                end
                pr = pr * y(i);
                sm = sm + pr;
            end

            sm = simplify(sm);
            dsm = diff(sm, xp);
            dy = double(subs(dsm, xp, x));

            % Store results
            result.x = x;
            result.y = y;
            result.dy = dy;
            result.polynomial = sm;
            result.derivative = dsm;
        end

        function display_result(obj, result)
            fprintf('\n=== Lagrange Method Results ===\n');
            fprintf('Function range: %.2f to %.2f\n', obj.lower_limit, obj.upper_limit);
            fprintf('Number of steps: %d\n', obj.num_steps);
            
            figure;
            plot(result.x, result.y, 'bo-', 'LineWidth', 2);
            hold on;
            plot(result.x, result.dy, 'r*-', 'LineWidth', 2);
            legend('Original Function', 'Estimated Derivative');
            xlabel('x');
            ylabel('y');
            title('Lagrange Numerical Differentiation');
            grid on;
        end
    end
end