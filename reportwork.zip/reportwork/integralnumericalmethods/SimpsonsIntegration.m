classdef SimpsonsIntegration < NumericalIntegration
    methods
        function obj = SimpsonsIntegration(a,b,n)
            obj@NumericalIntegration(a,b,n);
        end

        function result = integrate(obj, f)
            if mod(obj.n, 2) ~= 0
                error('n must be even for Simpson''s 1/3 rule.');
            end
            h = (obj.b - obj.a) / obj.n;
            x = obj.a:h:obj.b;
            y = f(x);
            result = (h/3) * (y(1) + 4 * sum(y(2:2:end-1)) + 2 * sum(y(3:2:end-2)) + y(end));
        end
    end
end
