%% Test 1: Trapezoidal Integration
fprintf('1. Testing Trapezoidal Integration...\n');
test_func = @(x) x.^2 + 2*x + 1;
trap_solver = TrapezoidalIntegration(0, 4, 100);
result1 = trap_solver.integrate(test_func);
fprintf('Trapezoidal Result: %.6f\n', result1);
fprintf('Exact integral from 0 to 4 of (x^2 + 2x + 1) dx = [x^3/3 + x^2 + x]_0^4 = 64/3 + 16 + 4 = 37.333...\n\n');

%% Test 2: Simpson's Integration
fprintf('2. Testing Simpson''s Integration...\n');
simp_solver = SimpsonsIntegration(0, 4, 100); % n must be even
result2 = simp_solver.integrate(test_func);
fprintf('Simpson''s Result: %.6f\n', result2);
fprintf('Exact integral: 37.333333...\n\n');

%% Test 3: Integral Fixed Point
fprintf('3. Testing Integral Fixed Point...\n');
% Example: Solve x = cos(x) using fixed point iteration
fp_func = @(x) cos(x);
fp_solver = IntegralFixedPoint(0, 1, 50, 100, 1e-8, 0.5);
result3 = fp_solver.integrate(fp_func);

fprintf('Fixed Point Results:\n');
fprintf('Solution: %.6f\n', result3.solution);
fprintf('Iterations: %d\n', result3.iterations);
fprintf('Final error: %e\n', result3.final_error);
fprintf('Converged: %s\n', string(result3.converged));
fprintf('Exact solution of x = cos(x) is approximately 0.739085\n\n');

%% Compare all methods for a simple integral
fprintf('=== Comparison: Integral of x^2 from 0 to 2 ===\n');
simple_func = @(x) x.^2;

% Trapezoidal
trap_result = TrapezoidalIntegration(0, 2, 50).integrate(simple_func);
fprintf('Trapezoidal: %.6f\n', trap_result);

% Simpson's
simp_result = SimpsonsIntegration(0, 2, 50).integrate(simple_func);
fprintf('Simpson''s: %.6f\n', simp_result);

% Exact value
exact = (2^3)/3; % ∫x² dx from 0 to 2 = [x³/3]_0^2 = 8/3
fprintf('Exact: %.6f\n', exact);
fprintf('Error - Trapezoidal: %.6f, Simpson''s: %.6f\n', ...
    abs(trap_result - exact), abs(simp_result - exact));

fprintf('\n=== All tests completed! ===\n');