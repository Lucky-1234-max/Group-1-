classdef (Abstract) NumericalIntegration
    % Abstract Base Class for Numerical Integration Methods
    % Demonstrates Abstraction and Encapsulation

    properties (Access = protected)
        a      % lower limit
        b      % upper limit
        n      % number of subintervals
    end

    methods
        function obj = NumericalIntegration(a, b, n)
            if nargin < 3
                error('Provide a, b and n when constructing a NumericalIntegration object.');
            end
            obj.a = a;
            obj.b = b;
            obj.n = n;
        end
    end

    methods (Abstract)
        result = integrate(obj, f);
    end
end
