function integralmethods_gui()
    % Create main window
    figure('Name', 'Integral Solver', 'Position', [100 100 500 400]);
    
    % Method selection
    uicontrol('Style', 'text', 'String', 'Choose Method:', 'Position', [50 350 100 20]);
    method_menu = uicontrol('Style', 'popupmenu', 'Position', [160 350 150 25], ...
        'String', {'Trapezoidal', 'Simpson', 'Fixed Point'});
    
    % Input fields
    uicontrol('Style', 'text', 'String', 'Function f(x):', 'Position', [50 310 100 20]);
    func_box = uicontrol('Style', 'edit', 'Position', [160 310 200 25], ...
        'String', 'x.^2 + 2*x + 1');
    
    uicontrol('Style', 'text', 'String', 'From:', 'Position', [50 270 50 20]);
    low_box = uicontrol('Style', 'edit', 'Position', [100 270 60 25], 'String', '0');
    
    uicontrol('Style', 'text', 'String', 'To:', 'Position', [170 270 30 20]);
    high_box = uicontrol('Style', 'edit', 'Position', [200 270 60 25], 'String', '4');
    
    uicontrol('Style', 'text', 'String', 'Steps:', 'Position', [270 270 50 20]);
    steps_box = uicontrol('Style', 'edit', 'Position', [320 270 50 25], 'String', '100');
    
    % Solve button
    uicontrol('Style', 'pushbutton', 'String', 'SOLVE', 'Position', [50 230 100 30], ...
        'Callback', @solve_problem);
    
    % Results display
    result_text = uicontrol('Style', 'text', 'String', 'Results will appear here', ...
        'Position', [50 150 400 60], 'BackgroundColor', [0.95 0.95 0.95], ...
        'HorizontalAlignment', 'left');
    
    function solve_problem(~, ~)
        try
            % Get inputs
            f = str2func(['@(x)' get(func_box, 'String')]);
            a = str2double(get(low_box, 'String'));
            b = str2double(get(high_box, 'String'));
            n = str2double(get(steps_box, 'String'));
            method = get(method_menu, 'Value');
            
            % Solve using selected method
            switch method
                case 1 % Trapezoidal
                    solver = TrapezoidalIntegration(a, b, n);
                    result = solver.integrate(f);
                    result_str = sprintf('Trapezoidal Rule\nIntegral = %.6f', result);
                    
                case 2 % Simpson
                    solver = SimpsonsIntegration(a, b, n);
                    result = solver.integrate(f);
                    result_str = sprintf('Simpson''s Rule\nIntegral = %.6f', result);
                    
                case 3 % Fixed Point
                    solver = IntegralFixedPoint(a, b, n, 100, 1e-8, (a+b)/2);
                    result = solver.integrate(f);
                    result_str = sprintf('Fixed Point Method\nSolution = %.6f\nIterations = %d\nError = %e', ...
                        result.solution, result.iterations, result.final_error);
            end
            
            % Display results
            set(result_text, 'String', result_str);
            
        catch ME
            set(result_text, 'String', ['Error: ' ME.message]);
        end
    end
end